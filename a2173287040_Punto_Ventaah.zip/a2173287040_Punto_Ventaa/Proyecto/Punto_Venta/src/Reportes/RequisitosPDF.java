package Reportes;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;

public class RequisitosPDF {

    public void generarPDF(String rutaArchivo) {
        Document documento = new Document();

        try {
            // Crear el archivo PDF
            PdfWriter.getInstance(documento, new FileOutputStream(rutaArchivo));
            documento.open();

            // Fuente para títulos
            Font fuenteTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLUE);
            Font fuenteSubtitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.DARK_GRAY);
            Font fuenteContenido = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);

            // Título del documento
            Paragraph titulo = new Paragraph("Requisición de Requisitos de Software", fuenteTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(20);
            documento.add(titulo);

            // Sección 1: Introducción
            Paragraph introduccion = new Paragraph("1. Introducción", fuenteSubtitulo);
            documento.add(introduccion);
            documento.add(new Paragraph("Este documento describe los requisitos funcionales y no funcionales " +
                    "para el desarrollo de un sistema de punto de venta (POS).", fuenteContenido));
            documento.add(Chunk.NEWLINE);

            // Sección 2: Requisitos Funcionales
            Paragraph requisitosFuncionales = new Paragraph("2. Requisitos Funcionales", fuenteSubtitulo);
            documento.add(requisitosFuncionales);

            // Tabla para los requisitos funcionales
            PdfPTable tablaFuncionales = new PdfPTable(2);
            tablaFuncionales.setWidthPercentage(100);
            tablaFuncionales.setSpacingBefore(10);
            tablaFuncionales.setSpacingAfter(10);

            // Encabezados de la tabla
            PdfPCell celdaEncabezado = new PdfPCell(new Phrase("Requisito", fuenteContenido));
            celdaEncabezado.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tablaFuncionales.addCell(celdaEncabezado);

            celdaEncabezado = new PdfPCell(new Phrase("Descripción", fuenteContenido));
            celdaEncabezado.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tablaFuncionales.addCell(celdaEncabezado);

            // Contenido de la tabla
            agregarFila(tablaFuncionales, "RF-01", "Registrar productos en el sistema.");
            agregarFila(tablaFuncionales, "RF-02", "Modificar datos de productos existentes.");
            agregarFila(tablaFuncionales, "RF-03", "Eliminar productos del sistema.");
            agregarFila(tablaFuncionales, "RF-04", "Generar ventas y actualizar el stock de productos.");
            agregarFila(tablaFuncionales, "RF-05", "Generar comprobantes de venta en formato PDF.");

            documento.add(tablaFuncionales);

            // Sección 3: Requisitos No Funcionales
            Paragraph requisitosNoFuncionales = new Paragraph("3. Requisitos No Funcionales", fuenteSubtitulo);
            documento.add(requisitosNoFuncionales);

            // Lista de requisitos no funcionales
            List listaNoFuncionales = new List(List.UNORDERED);
            listaNoFuncionales.add(new ListItem("El sistema debe responder en menos de 2 segundos.", fuenteContenido));
            listaNoFuncionales.add(new ListItem("La interfaz debe ser intuitiva y fácil de usar.", fuenteContenido));
            listaNoFuncionales.add(new ListItem("El sistema debe soportar al menos 10,000 registros.", fuenteContenido));
            listaNoFuncionales.add(new ListItem("Los datos sensibles deben estar cifrados.", fuenteContenido));

            documento.add(listaNoFuncionales);

            // Sección 4: Conclusión
            Paragraph conclusion = new Paragraph("4. Conclusión", fuenteSubtitulo);
            documento.add(conclusion);
            documento.add(new Paragraph("Este documento proporciona una guía clara para el desarrollo del sistema " +
                    "de punto de venta, asegurando que cumpla con las expectativas del usuario.", fuenteContenido));

            // Cerrar el documento
            documento.close();

            System.out.println("PDF generado exitosamente en: " + rutaArchivo);

        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para agregar filas a la tabla
    private void agregarFila(PdfPTable tabla, String requisito, String descripcion) {
        tabla.addCell(new PdfPCell(new Phrase(requisito)));
        tabla.addCell(new PdfPCell(new Phrase(descripcion)));
    }

    public static void main(String[] args) {
        RequisitosPDF generadorPDF = new RequisitosPDF();
        generadorPDF.generarPDF("Requisitos_Software.pdf");
    }
}