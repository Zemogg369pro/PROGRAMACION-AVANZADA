package Reportes;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;

public class ManualPDF {

    public static void main(String[] args) {
        // Ruta donde se guardará el archivo PDF
        String rutaArchivo = "Manual_Usuario_Mejorado.pdf";

        // Crear el documento PDF
        Document documento = new Document();

        try {
            // Inicializar el escritor del PDF
            PdfWriter.getInstance(documento, new FileOutputStream(rutaArchivo));

            // Abrir el documento
            documento.open();

            // Agregar imagen del logo
            Image logo = Image.getInstance("src/IMGG/programmer.png");
            logo.scaleToFit(100, 100); // Ajustar tamaño
            logo.setAlignment(Element.ALIGN_CENTER);
            documento.add(logo);

            // Título del manual
            Font tituloFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph titulo = new Paragraph("Manual de Usuario - Sistema de Punto de Venta", tituloFont);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(20); // Espacio después del título
            documento.add(titulo);

            // Contenido del manual
            Font seccionFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.BLUE);
            Font contenidoFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);

            // Sección 1: Introducción
            Paragraph introduccion = new Paragraph("1. Introducción", seccionFont);
            documento.add(introduccion);
            documento.add(new Paragraph("Bienvenido al sistema de punto de venta.", contenidoFont));
            documento.add(new Paragraph("Este manual le guiará sobre cómo utilizar las principales funcionalidades del sistema. "
                    + "El sistema está diseñado para gestionar ventas, productos, clientes, proveedores y configuraciones generales de la empresa. "
                    + "Cada sección describe paso a paso cómo realizar las operaciones más comunes.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de ejemplo
            Image imgIntro = Image.getInstance("src/IMGG/programmer.png");
            imgIntro.scaleToFit(400, 200);
            imgIntro.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgIntro);

            // Sección 2: Inicio de Sesión
            Paragraph inicioSesion = new Paragraph("2. Inicio de Sesión", seccionFont);
            documento.add(inicioSesion);
            documento.add(new Paragraph("- Abra el sistema e ingrese su nombre de usuario y contraseña.", contenidoFont));
            documento.add(new Paragraph("- Haga clic en 'Iniciar Sesión' para acceder al menú principal.", contenidoFont));
            documento.add(new Paragraph("- Si olvidó sus credenciales, contacte al administrador del sistema.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de inicio de sesión
            Image imgLogin = Image.getInstance("src/IMGG/programmer.png");
            imgLogin.scaleToFit(300, 200);
            imgLogin.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgLogin);

            // Sección 3: Registrar una Venta
            Paragraph registrarVenta = new Paragraph("3. Registrar una Venta", seccionFont);
            documento.add(registrarVenta);
            documento.add(new Paragraph("- Seleccione la opción 'Nueva Venta' en el menú principal.", contenidoFont));
            documento.add(new Paragraph("- Busque un cliente ingresando su DNI o RUC. Si el cliente no existe, regístrelo en la sección de clientes.", contenidoFont));
            documento.add(new Paragraph("- Agregue productos ingresando su código y cantidad. El sistema mostrará automáticamente el precio unitario y el total.", contenidoFont));
            documento.add(new Paragraph("- Finalice la venta haciendo clic en 'Generar Venta'. El sistema generará un recibo y actualizará el inventario.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de registro de venta
            Image imgVenta = Image.getInstance("src/IMGG/programmer.png");
            imgVenta.scaleToFit(400, 200);
            imgVenta.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgVenta);

            // Sección 4: Gestionar Productos
            Paragraph gestionarProductos = new Paragraph("4. Gestionar Productos", seccionFont);
            documento.add(gestionarProductos);
            documento.add(new Paragraph("- Acceda a la pestaña 'Productos'.", contenidoFont));
            documento.add(new Paragraph("- Para agregar un producto, haga clic en 'Nuevo Producto' y complete los campos obligatorios: código, nombre, proveedor, stock y precio.", contenidoFont));
            documento.add(new Paragraph("- Para editar o eliminar un producto, selecciónelo en la tabla y use los botones correspondientes.", contenidoFont));
            documento.add(new Paragraph("- El sistema permite buscar productos por código o nombre para facilitar la gestión.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de gestión de productos
            Image imgProductos = Image.getInstance("src/IMGG/programmer.png");
            imgProductos.scaleToFit(400, 200);
            imgProductos.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgProductos);

            // Sección 5: Gestionar Clientes
            Paragraph gestionarClientes = new Paragraph("5. Gestionar Clientes", seccionFont);
            documento.add(gestionarClientes);
            documento.add(new Paragraph("- Acceda a la pestaña 'Clientes'.", contenidoFont));
            documento.add(new Paragraph("- Para agregar un cliente, haga clic en 'Nuevo Cliente' y complete los campos obligatorios: DNI/RUC, nombre, teléfono y dirección.", contenidoFont));
            documento.add(new Paragraph("- Para editar o eliminar un cliente, selecciónelo en la tabla y use los botones correspondientes.", contenidoFont));
            documento.add(new Paragraph("- El sistema permite buscar clientes por DNI/RUC o nombre para facilitar la gestión.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de gestión de clientes
            Image imgClientes = Image.getInstance("src/IMGG/programmer.png");
            imgClientes.scaleToFit(400, 200);
            imgClientes.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgClientes);

            // Sección 6: Generar Reportes
            Paragraph generarReportes = new Paragraph("6. Generar Reportes", seccionFont);
            documento.add(generarReportes);
            documento.add(new Paragraph("- En la pestaña 'Ventas', seleccione una venta para generar un PDF con los detalles.", contenidoFont));
            documento.add(new Paragraph("- Use la opción 'Generar Gráfico' para visualizar las ventas por fecha. El gráfico muestra un resumen visual de las ventas diarias.", contenidoFont));
            documento.add(new Paragraph("- Los reportes son útiles para analizar el rendimiento del negocio y tomar decisiones informadas.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de generación de reportes
            Image imgReportes = Image.getInstance("src/IMGG/programmer.png");
            imgReportes.scaleToFit(400, 200);
            imgReportes.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgReportes);

            // Sección 7: Configuración de la Empresa
            Paragraph configuracionEmpresa = new Paragraph("7. Configuración de la Empresa", seccionFont);
            documento.add(configuracionEmpresa);
            documento.add(new Paragraph("- Acceda a la pestaña 'Configuración'.", contenidoFont));
            documento.add(new Paragraph("- Modifique los datos generales de la empresa, como el RUC, nombre, teléfono, dirección y mensaje para facturas.", contenidoFont));
            documento.add(new Paragraph("- Asegúrese de guardar los cambios para que se reflejen en el sistema.", contenidoFont));
            documento.add(new Paragraph("- Esta información se utiliza en los reportes y recibos generados por el sistema.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Agregar imagen de configuración de la empresa
            Image imgConfiguracion = Image.getInstance("src/IMGG/programmer.png");
            imgConfiguracion.scaleToFit(400, 200);
            imgConfiguracion.setAlignment(Element.ALIGN_CENTER);
            documento.add(imgConfiguracion);

            // Sección 8: Solución de Problemas Comunes
            Paragraph solucionProblemas = new Paragraph("8. Solución de Problemas Comunes", seccionFont);
            documento.add(solucionProblemas);
            documento.add(new Paragraph("- Error al iniciar sesión: Verifique que el nombre de usuario y la contraseña sean correctos.", contenidoFont));
            documento.add(new Paragraph("- No se puede conectar a la base de datos: Asegúrese de que el servidor de la base de datos esté en funcionamiento y que las credenciales sean correctas.", contenidoFont));
            documento.add(new Paragraph("- No se genera el PDF: Verifique que la librería iTextPDF esté correctamente instalada y que tenga permisos para guardar archivos en su computadora.", contenidoFont));
            documento.add(new Paragraph("- Stock incorrecto: Revise que los productos registrados tengan cantidades adecuadas en el inventario.", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Sección 9: Contacto y Soporte
            Paragraph contactoSoporte = new Paragraph("9. Contacto y Soporte", seccionFont);
            documento.add(contactoSoporte);
            documento.add(new Paragraph("- Si tiene preguntas o necesita asistencia adicional, contacte al equipo de soporte técnico.", contenidoFont));
            documento.add(new Paragraph("- Correo electrónico: soporte@empresa.com", contenidoFont));
            documento.add(new Paragraph("- Teléfono: +51 999 999 999", contenidoFont));
            documento.add(new Paragraph("- Horario de atención: Lunes a Viernes, 8:00 AM - 5:00 PM", contenidoFont));
            documento.add(new Paragraph("\n"));

            // Cerrar el documento
            documento.close();

            System.out.println("El manual ha sido generado exitosamente en: " + rutaArchivo);

        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }
    }
}