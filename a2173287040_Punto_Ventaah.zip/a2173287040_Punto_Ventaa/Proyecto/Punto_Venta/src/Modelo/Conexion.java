package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    Connection con;

    public Connection getConnection() {
        try {
            // URL de conexión a SQL Server
            String url = "jdbc:sqlserver://PCPRO\\SQLEXPRESS;databaseName=Ventadb;encrypt=true;trustServerCertificate=true;";
            String user = "Basepro";
            String password = "123456";

            // Cargar el driver JDBC de SQL Server
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Establecer la conexión
            con = DriverManager.getConnection(url, user, password);
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }
}