package aloproo;

public interface ImpuestoAplicable {
    double calcularIVA();
    double calcularIEPS();
}